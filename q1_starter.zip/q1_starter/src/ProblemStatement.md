### Change the app to use the useContext hook to access the value of context instead of the Consumer component

Refactor the app to use the useContext hook to get the value the context instead of the Consumer component.
