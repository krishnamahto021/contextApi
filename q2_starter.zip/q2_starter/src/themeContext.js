const { createContext} = require("react");

// create theme context here
export const themeContext = createContext();


