import { createContext } from "react";

// create language context here
export const languageContext = createContext();
